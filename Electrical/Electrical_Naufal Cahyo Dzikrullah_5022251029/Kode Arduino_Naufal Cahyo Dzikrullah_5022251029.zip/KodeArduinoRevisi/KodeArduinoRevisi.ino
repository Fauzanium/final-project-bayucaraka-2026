#include <Servo.h>

#define STEP_X 5
#define DIR_X  4

#define STEP_Y 3
#define DIR_Y  2

#define SERVO_GRIP 10

#define STEP_PER_CM 20
#define PULSE_DELAY 400

Servo gripServo;

long currentStepX = 0;
long currentStepY = 0;

// GERAK MOTOR STEPPER
void moveStepper(long deltaX, long deltaY) {

  digitalWrite(DIR_X, deltaX >= 0 ? HIGH : LOW);
  digitalWrite(DIR_Y, deltaY >= 0 ? HIGH : LOW);

  deltaX = abs(deltaX);
  deltaY = abs(deltaY);

  long maxStep = max(deltaX, deltaY);

  for (long i = 0; i < maxStep; i++) {

    if (i < deltaX)
      digitalWrite(STEP_X, HIGH);

    if (i < deltaY)
      digitalWrite(STEP_Y, HIGH);

    delayMicroseconds(PULSE_DELAY);

    digitalWrite(STEP_X, LOW);
    digitalWrite(STEP_Y, LOW);

    delayMicroseconds(PULSE_DELAY);
  }
}

// GERAK KE KOORDINAT
void moveTo(float targetX_cm, float targetY_cm) {

  long targetStepX = targetX_cm * STEP_PER_CM;
  long targetStepY = targetY_cm * STEP_PER_CM;

  long deltaX = targetStepX - currentStepX;
  long deltaY = targetStepY - currentStepY;

  moveStepper(deltaX, deltaY);

  currentStepX = targetStepX;
  currentStepY = targetStepY;

  Serial.println("OK");
}

// SERVO GRIPPER 
void gripOpen() {
  gripServo.write(20);  
  delay(500);
}

void gripClose() {
  gripServo.write(90);   
  delay(500);
}

void setup() {

  Serial.begin(115200);

  pinMode(STEP_X, OUTPUT);
  pinMode(DIR_X, OUTPUT);
  pinMode(STEP_Y, OUTPUT);
  pinMode(DIR_Y, OUTPUT);

  gripServo.attach(SERVO_GRIP);

  gripClose();

  Serial.println("READY");
}

void loop() {

  if (Serial.available()) {

    String cmd = Serial.readStringUntil('\n');
    cmd.trim();

    float x, y;
 
    // MOVE KE PAYLOAD
        if (cmd.startsWith("MOVE_PAYLOAD")) {

      int c1 = cmd.indexOf(',');
      int c2 = cmd.indexOf(',', c1 + 1);

      x = cmd.substring(c1 + 1, c2).toFloat();
      y = cmd.substring(c2 + 1).toFloat();

      moveTo(x, y);
    }
    
    // GRIP PAYLOAD
     else if (cmd == "GRIP") {

      gripOpen();
      gripClose();

      Serial.println("GRIPPED");
    }
    
    // MOVE KE TARGET
        else if (cmd.startsWith("MOVE")) {

      int c1 = cmd.indexOf(',');
      int c2 = cmd.indexOf(',', c1 + 1);

      x = cmd.substring(c1 + 1, c2).toFloat();
      y = cmd.substring(c2 + 1).toFloat();

      moveTo(x, y);
    }

    // DROP
        else if (cmd == "DROP") {

      gripOpen();
      delay(300);
      gripClose();

      Serial.println("DROPPED");
    }
  }
}